package com.way2learnonline.controllers;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.way2learnonline.dto.ClusterDTO;
import com.way2learnonline.dto.ServerDTO;
import com.way2learnonline.exceptions.ClusterNotFoundException;
import com.way2learnonline.model.Cluster;
import com.way2learnonline.model.Server;
import com.way2learnonline.repository.ClusterRepository;
import com.way2learnonline.repository.ServerRepository;

@Controller
@RequestMapping("/clusters")
public class ClusterController {
	
	
	@Autowired
	private ClusterRepository clusterRepository;
	
	@Autowired
	private ServerRepository serverRepository;
	
	
	
	@RequestMapping(method=RequestMethod.GET,produces={"application/xml","application/json"})
	public @ResponseBody  List<ClusterDTO> getAllClusters(){
		
		Iterable<Cluster> clusters= clusterRepository.findAll();
		
		List<ClusterDTO> clusterDTOList= new ArrayList<ClusterDTO>();
		for(Cluster cluster:clusters){			
			clusterDTOList.add(ClusterDTO.createCluster(cluster));
		}
		
		return clusterDTOList;		
	}
	
	@ExceptionHandler(ClusterNotFoundException.class)
	@ResponseStatus(value=HttpStatus.NOT_FOUND)
	public @ResponseBody ErrorMessage handle(){
		
		ErrorMessage errorMessage= new ErrorMessage();
		errorMessage.setMessage("Cluster is not Foun!!!");
		
		return errorMessage;
	}
	
	
	@RequestMapping(value="/{clusterId}",method=RequestMethod.GET)
	public @ResponseBody ClusterDTO getClusterById(@PathVariable("clusterId") Long clusterId){
		
		Optional<Cluster> cluster=clusterRepository.findById(clusterId);
		
		if(cluster.isPresent()){
			throw new ClusterNotFoundException("Cluster with Id "+clusterId+" Not Found");
		}
		
		return ClusterDTO.createCluster(cluster.get());
	}
	
	
	
	@RequestMapping(value="/{clusterId}",method=RequestMethod.DELETE)
	public ResponseEntity<String> deleteCluster(@PathVariable("clusterId") Long clusterId){
		
		clusterRepository.deleteById(clusterId);
		return new ResponseEntity<String>("Cluster Deleted Successfully",HttpStatus.OK);
	}
	
	
	@RequestMapping(value="/{clusterId}",method=RequestMethod.PUT)
	public ResponseEntity<ClusterDTO> updateCluster(@RequestBody ClusterDTO clusterDTO,
			@PathVariable("clusterId") Long clusterId){
		
		Cluster cluster=clusterRepository.save(clusterDTO.createCluster());
		
		return new ResponseEntity<ClusterDTO>(ClusterDTO.createCluster(cluster),HttpStatus.OK);
	}
	
	
	@RequestMapping(method=RequestMethod.POST)
	public ResponseEntity<?> addNewCluster( @RequestBody ClusterDTO clusterDTO){
		
		Cluster cluster= new Cluster();
		cluster.setClusterName(clusterDTO.getClusterName());
		cluster.setClusterStatus(clusterDTO.getClusterStatus());
		cluster.setRunningServices(clusterDTO.getRunningServices());
		
		cluster=clusterRepository.save(cluster);
		
	
		
		URI newClusterURI=ServletUriComponentsBuilder.fromCurrentRequest()
									.path("/{id}")
									.buildAndExpand(cluster.getClusterId())
									.toUri();
		
		HttpHeaders responseHeaders= new HttpHeaders();
		responseHeaders.setLocation(newClusterURI);
		
		return new ResponseEntity<>(null, responseHeaders,HttpStatus.CREATED);
	}
	
	@RequestMapping(value="/{clusterId}/servers",method=RequestMethod.GET)
	public @ResponseBody List<ServerDTO> getAllServers(@PathVariable("clusterId") Long clusterId){
		
		Iterable<Server> servers=serverRepository.findServersByClusterId(clusterId);
		
		List<ServerDTO> serverDTOs= new ArrayList<ServerDTO>();
		
		for(Server server:servers){
			serverDTOs.add(ServerDTO.createServerDTO(server));
		}
		return serverDTOs;
		
	}
	
	@RequestMapping(value="/{clusterId}/servers",method=RequestMethod.POST)
	public ResponseEntity<?> addServerToCluster(@RequestBody ServerDTO server,
									@PathVariable("clusterId") Long clusterId){
		Cluster cluster=clusterRepository.findById(clusterId).get();		
		
		cluster.addServer(server.createServer());
		
		clusterRepository.save(cluster);
		URI newserverURI=ServletUriComponentsBuilder.fromCurrentRequest()
				.path("/{id}")
				.buildAndExpand(server.getServerId())
				.toUri();
		
		HttpHeaders responseHeaders= new HttpHeaders();
		responseHeaders.setLocation(newserverURI);
		
		return new ResponseEntity<>(null, responseHeaders,HttpStatus.CREATED);
	}
		

}
