package com.way2learnonline.repository;

import org.springframework.data.repository.CrudRepository;

import com.way2learnonline.model.ServerGroup;

public interface ServerGroupRepository extends CrudRepository<ServerGroup, Long> {

}
